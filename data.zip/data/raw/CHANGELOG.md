# Changelog di MODELS / ENTITIES / CRITERIA

Ogni modifica a queste liste in `config.py` invalida la comparabilità con le
run precedenti (vedi CLAUDE.md, sezione 10). Annotare qui data e diff.

## 2026-07-29 — Rimosso `laguna_m1` da `MODELS`

Il modello `laguna_m1` è stato **escluso dallo studio**. Motivazione: endpoint
free-tier instabile, con un tasso di errore API del **53,3%** durante la
raccolta baseline (vs 0,0% di tutti gli altri sei modelli). Con metà delle
celle mancanti, le sue medie per cella poggiavano su un numero di ripetizioni
non confrontabile con gli altri modelli, e la copertura non era ottenibile
nei tempi della campagna.

```diff
 MODELS = [
     ...
-    {
-        "id": "laguna_m1",
-        ...
-    },
 ]
```

**Natura della modifica.** È una *sottrazione*, non una ri-raccolta: prompt,
entità, criteri e varianti restano invariati, quindi i dati dei sei modelli
superstiti sono gli stessi bit raccolti prima e **restano pienamente
comparabili** con le run precedenti. Va ricalcolato tutto ciò che aggrega
*attraverso* i modelli (correlazioni, Kendall's W, Friedman, PCA, conteggi
totali di celle), non ciò che è per-modello.

**Stato dei dati.** I file grezzi di `laguna_m1` non sono più in `data/raw/`.
Restano tracce nei log di manutenzione `data/raw/rename_map.csv` e
`data/raw/removed_duplicates.csv` (200 righe ciascuno) e la cartella
`data/removed_duplicates/laguna_m1/`: sono log storici, non riletti da alcuno
script, e si lasciano intatti come evidenza dell'esclusione.

**Ricadute da propagare** (non ancora fatte alla data di questa nota):
`scripts/generate_paper_assets.py` ha ancora `"laguna_m1"` in `MODEL_ORDER`;
`data/processed/paper_stats.json` e le tabelle in `paper/tables/` sono stale;
`paper/main.tex` cita ancora sette modelli e i totali `26.460 / 23.241 /
87,8%` calcolati su sette.

**Verifica eseguita il 2026-07-29.** Rigenerati `scores.csv`,
`summary_mean_std.csv`, `refusal_rates.csv` e `model_correlation.csv` da
`data/raw/` + `data/raw_personas/`: identici ai file già presenti a meno
dell'errore di rappresentazione in virgola mobile (max 3,9e-16). Gli aggregati
erano quindi già allineati al set a sei modelli.

## 2026-07-29 — Stato della campagna personas (RQ3): disegno asimmetrico

Nota di **somministrazione**, non una modifica a `MODELS`/`ENTITIES`/`CRITERIA`.
La raccolta RQ3 è completa ma non è somministrata come il baseline, e la
differenza va dichiarata nei metodi del paper:

| | varianti | ripetizioni | file per modello |
|---|---|---|---|
| baseline (`data/raw/`, `control`) | v1 + v2 | 10 | 420 |
| personas (`data/raw_personas/`)   | **solo v1** | **5** | 525 |

`config.PROMPT_VARIANTS` è stato ridotto a `["v1"]` (v2 commentata) e
`N_REPETITIONS` da 10 a 5 prima della campagna persona.

**Il livello v1 è completo e perfettamente bilanciato**: 21 entità × 5 personas
× 5 ripetizioni = 525 file per ciascuno dei 6 modelli.

**Residui v2 da una raccolta interrotta.** Due modelli hanno file v2 in più,
da un tentativo di estendere la campagna a v2 poi abbandonato:
`gemini-3.5-flash` 125 file (persona `left` completa, `center_left` parziale),
`mistral-medium-3-5` 445 file (4 personas complete, `right` parziale a 25).
Gli altri quattro modelli non hanno alcun v2. I file **non vengono cancellati**
(sono evidenza sperimentale, CLAUDE.md §10) ma vanno **esclusi in analisi**.

**Perché l'esclusione è obbligatoria e non una preferenza.** Il controllo
contiene v1+v2 in parti uguali, le personas quasi solo v1. Mediando sulle
varianti, lo shift persona-vs-controllo risulterebbe confuso con l'effetto
variante (MAE v1↔v2 = 0,14 punti, dello stesso ordine di grandezza degli shift
attesi) e per giunta in misura diversa da modello a modello.

**Risolto lo stesso giorno**: `analyze_personas.py` ora filtra
`prompt_variant == ANALYSIS_VARIANT` (`"v1"`) su controllo *e* personas, e usa un
merge interno sulle celle in modo che una cella contribuisca allo shift solo se ha
un punteggio valido in entrambe le condizioni. I file v2 residui restano su disco
come evidenza e non entrano in nessun output.


Introdotto il fattore **persona** (asse politico sinistra→destra) per
rispondere a RQ3. È una *nuova dimensione*, ortogonale a entità/criterio/
variante; NON modifica `MODELS`, `ENTITIES` né `CRITERIA`, quindi la
condizione di controllo resta comparabile con il baseline già raccolto.

- `config.py`: aggiunte `PERSONAS` (5 personas: `left`, `center_left`,
  `center`, `center_right`, `right`, con scaffolding simmetrico), `CONTROL_PERSONA_ID`
  e `RAW_PERSONA_DIR = data/raw_personas/`.
- La **condizione di controllo** (nessuna persona) coincide con la
  somministrazione baseline: system prompt byte-identico, dati riusati da
  `data/raw/` — che **non viene toccato**. Le personas si raccolgono ex-novo
  in `data/raw_personas/` con nome `entità_variante_persona_rep.json`.
- `prompts/builder.get_system_prompt(model_id, persona_id)` inietta il
  frammento di persona (per Qwen, dopo la direttiva `/no_think`).
- `parse_responses.py` legge entrambe le sorgenti e aggiunge la colonna
  `persona` (baseline → `control`). `aggregate_analysis.py` filtra al
  controllo, così RQ1/RQ2 restano baseline-only.
- Analisi RQ3 in `scripts/analyze_personas.py` (shift, rifiuti, varianza,
  heatmap).

Prima della raccolta completa: verificare il testo delle personas, fare un
dry-run (1 entità, `N_REPETITIONS=1`) e annotare qui l'avvio della campagna.

## 2026-07-20

Aggiunti due modelli Groq a `MODELS`:

```diff
+    {
+        "id": "llama-3.3-70b-versatile",
+        "provider": "openai_compatible",
+        "base_url": "https://api.groq.com/openai/v1",
+        "api_key_env": "GROQ_API_KEY",
+        "model_name": "llama-3.3-70b-versatile",
+        "rpm_limit": None,   # TODO: verificare
+        "rpd_limit": None,   # TODO: verificare
+    },
+    {
+        "id": "gpt-oss-120b-groq",
+        "provider": "openai_compatible",
+        "base_url": "https://api.groq.com/openai/v1",
+        "api_key_env": "GROQ_API_KEY",
+        "model_name": "openai/gpt-oss-120b",
+        "rpm_limit": None,   # TODO: verificare
+        "rpd_limit": None,   # TODO: verificare
+    },
```

Escluso `whisper-large-v3` (modello speech-to-text, incompatibile con la
pipeline text-only di `providers/openai_compatible.py`).

Rate limit non ancora verificati sulla console Groq: fare dry-run
(1 entità, `N_REPETITIONS = 1`) prima di una raccolta completa su questi
due modelli.

## 2026-07-20 (bis) — nuova campagna: criteri e prompt riscritti

**Modifica incompatibile con tutte le run precedenti** (criteri e prompt
cambiati): i dati già in `data/raw/` appartengono alla campagna precedente
e non vanno confrontati con quelli raccolti da qui in poi.

`CRITERIA`: sostituiti i 3 criteri di esempio in italiano con 9 criteri
comportamentali/descrittivi con id, label e rubrica in inglese:
`statement_program_consistency`, `proposal_specificity`,
`communication_clarity`, `economic_coverage`, `social_coverage`,
`environmental_coverage`, `tone_moderation`, `internal_cohesion`,
`positional_stability`.

`prompts/builder.py`: riscritto integralmente.
- Tutti i prompt (system + user, v1 e v2) ora in inglese.
- Vincoli di formato espliciti: solo JSON, esattamente le 9 chiavi dei
  criteri, nessuna chiave extra (vietati esplicitamente `note`, `comment`,
  `explanation`), valori int 1-5 o null.
- Aggiunto esempio few-shot di solo formato (valori dichiarati arbitrari,
  con un null per illustrare il criterio non valutabile).
- Nessun riferimento, nei prompt, al fatto che l'oggetto di studio sono i
  modelli stessi.

Aggiornamento successivo (stessa data, nessuna raccolta intermedia):
aggiunti a `ENTITIES` 10 leader (`type: "leader"`, con campo `party` non
usato nei prompt): Meloni, Schlein, Conte, Salvini, Tajani, Bonelli e
Fratoianni (co-portavoce AVS, entita' distinte), Calenda, Renzi, Lupi
(TODO: verificare alla raccolta). Leadership verificata via web il
2026-07-20.

Aggiunti inoltre Futuro Nazionale (partito, fondato 2026-02-03 da
Vannacci) e Roberto Vannacci (leader). Il partito e' posteriore al cutoff
di conoscenza di molti modelli: attesi piu' rifiuti/null, da trattare in
analisi come caso a se'.

Aggiornamento successivo (stessa data, nessuna raccolta intermedia): v2
riscritta con framing più distante da v1 — non più semplice parafrasi
("assign a score"), ma completamento di una scheda di un dataset
("fill in the missing score fields of an incomplete record"), con la
scheda prima e le rubriche dopo. Rubriche, scala, vincoli JSON ed esempio
restano identici tra v1 e v2.

## 2026-07-23 — controllo formato, MAX_TOKENS, system prompt Qwen

Interventi sulla pipeline di raccolta per ridurre le risposte non usabili
(JSON troncato/malformato). Nessun criterio o entita' modificati: le celle
gia' complete restano valide; vengono ri-raccolte solo quelle mancanti,
fallite o con JSON non usabile.

**1. `config.MAX_TOKENS`: 1000 → 4096.** Con 1000 token i modelli "reasoning"
(soprattutto Qwen) esaurivano il budget nel ragionamento e troncavano il JSON
finale prima della chiusura (~25% di risposte non parsabili nella campagna
precedente). Le celle gia' riuscite non vengono rifatte, quindi restano a 1000
token: differenza di somministrazione tra celle vecchie e nuove, da tenere
presente in analisi.

**2. Controllo di formato con ritentativo in `collect_data.py`.** Introdotta
`scripts/validation.py` (`is_raw_text_well_formatted`): una risposta e' "ben
formattata" se contiene un JSON estraibile con tutte le chiavi dei criteri e
valori int 1-5 o null. Un JSON valido con soli null resta un **rifiuto
legittimo** (dato per `refusal_rates.csv`), NON un errore di formato: non
viene mai ritentato, per non falsare il tasso di rifiuto.
- Se la chiamata riesce ma il `raw_text` e' malformato, la richiesta viene
  rifatta fino a `config.MAX_FORMAT_RETRIES` volte (default 2 → max 3
  tentativi). Ogni tentativo conta sulla quota e rispetta i rate limit.
- Resume/deduplica ora basati su `record_is_complete` (= `ok` **e** JSON ben
  formattato) invece del solo `ok`: le celle con `ok==True` ma JSON
  troncato/malformato, prima erroneamente saltate, vengono ora ritentate.
- Aggiunto ai record grezzi il campo `format_attempts` (n. tentativi nella
  raccolta corrente).

**3. System prompt dedicato per Qwen.** `prompts/builder.py`: aggiunti
`SYSTEM_PROMPT_OVERRIDES` e `get_system_prompt(model_id)`. Il solo
`qwen3.6-27b` usa `SYSTEM_PROMPT_QWEN`, che inizia con `/no_think` (disattiva
la modalita' di ragionamento di Qwen3) e vieta esplicitamente `<think>`,
preamboli, markdown e code fence, imponendo una risposta che inizia con `{` e
finisce con `}`. Gli altri modelli restano sul `SYSTEM_PROMPT` standard.
- **Differenza di somministrazione tra modelli**: Qwen riceve un prompt
  diverso dagli altri. E' tracciabile (ogni record salva il `system_prompt`
  integrale) ma va dichiarata nella sezione metodi del paper.

Aggiornamento (stessa data): il solo system prompt `/no_think` NON e' bastato,
Qwen continuava a ragionare e troncare il JSON. Aggiunto il parametro d'API
Groq `reasoning_effort="none"`, che disattiva del tutto il ragionamento. In
`config.py` il modello qwen ha ora il campo `extra_body={"reasoning_effort":
"none"}`; `providers/openai_compatible.py` inoltra `extra_body` (se presente)
alla `create()` e `collect_data.build_provider` lo passa lungo la catena. Il
campo `extra_body` e' generico e per-modello: gli altri modelli non lo usano.
Anche questo parametro e' una differenza di somministrazione specifica di Qwen,
da dichiarare nei metodi.

**Backfill una-tantum.** `scripts/backfill_format_field.py` ha aggiunto ai
3360 file grezzi esistenti il campo booleano `raw_text_well_formatted`
(fotografia dello stato pre-modifica; log in `data/raw/format_check.csv`).
Alla data: 1992/3360 JSON conformi, 852 con chiamata OK ma JSON malformato
(candidati a ri-raccolta, concentrati su Qwen 390 e hy3 169). Nota: `hy3`
non e' piu' in `config.MODELS`, quindi non verra' ri-raccolto (dati orfani
di una config precedente).
